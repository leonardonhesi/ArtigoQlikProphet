& $PSScriptRoot\qlik-py-env\Scripts\activate.ps1
cd $PSScriptRoot\qlik-py-env\core
python __main__.py