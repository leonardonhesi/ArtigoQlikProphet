qlik-py-tools version 8.1
--------------------------
Sample Qlik Sense apps and guidance on using this Server Side Extension are available at https://github.com/nabeel-oz/qlik-py-tools

More information on Qlik Server Side Extensions is available at https://github.com/qlik-oss/server-side-extension

License: See LICENSE.txt
